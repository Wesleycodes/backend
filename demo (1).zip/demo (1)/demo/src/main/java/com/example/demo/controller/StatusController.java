@RestController
@RequestMapping("/status")
public class StatusController {

    @GetMapping
    public String verificarStatus() {
        return "API do Sistema Bancário está online!";
    }
}